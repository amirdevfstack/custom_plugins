jQuery(document).ready(function($) {
    $('td.label label[for="pa_size"]').hide();
    $('.variant-image').on('click', function() {    
        var colorVariant = $(this).data('value');
        var product_id = $(this).data('product_id');
        alert(colorVariant);

        $.ajax({
            url: woocommerce_color_variants_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'get_sizes_for_color_variant',
                color_variant: colorVariant,
                product_id: product_id
            },
            success: function(response) {
                // alert(response);
                // return;
                if (response) {
                    var html = '<table class="size-variants-table">';
                    html += '<tr><th>Size</th><th>Price</th><th>Quantity</th><th>Select Quantity</th></tr>';
                    $.each(response, function(index, sizeData) {
                        var priceHtml = $('<div/>').html(sizeData.price).text();
                        html += '<tr>';
                        html += '<td>' + sizeData.size + '</td>';
                        html += '<td>' + priceHtml + '</td>';
                        html += '<td>' + sizeData.quantity + '</td>';
                        html += '<td><input type="number" class="size-quantity" data-size="' + sizeData.size + '" data-price="' + priceHtml + '" data-product-id="' + product_id + '" data-variation-id="' + sizeData.variation_id + '" data-color-variant="' + colorVariant + '" min="1" max="' + sizeData.quantity + '" value="1"></td>';
                        html += '</tr>';
                    });
                    html += '</table>';
                    html += '<button id="add-all-to-cart">Add All to Cart</button>';
                    $('#variant-data-placeholder').html(html);

                    $('#add-all-to-cart').on('click', function(e) {
                        e.preventDefault();
                        // alert('Adding all to cart');
                        // return;
                        var items = [];
                        $('.size-quantity').each(function() {
                            var quantity = $(this).val();
                            if (quantity > 0) {
                                items.push({
                                    size: $(this).data('size'),
                                    price: $(this).data('price'),
                                    product_id: $(this).data('product-id'),
                                    variation_id: $(this).data('variation-id'),
                                    color_variant: $(this).data('color-variant'),
                                    quantity: quantity
                                });
                            }
                        });
                        
                        if (items.length > 0) {
                            $.ajax({
                                url: woocommerce_color_variants_ajax.ajax_url,
                                type: 'POST',
                                data: {
                                    action: 'add_all_to_cart',
                                    items: items
                                },
                                success: function(response) {
                                    if (response.success) {
                                        alert('Items added to cart');
                                    } else {
                                        alert('Failed to add items to cart');
                                    }
                                }
                            });
                        }
                    });
                } else {
                    console.log('No data received from server');
                }
            }
        });
    });
});






































// jQuery(document).ready(function($) {
//     $('.variant-image').on('click', function() {    
//      var colorVariant = $(this).data('color');
//         var product_id = $(this).data('product_id');
//         alert(colorVariant);
      
//         $.ajax({
//             url: woocommerce_color_variants_ajax.ajax_url,
//             type: 'POST',
//             data: {
//                 action: 'get_sizes_for_color_variant',
//                 color_variant: colorVariant,
//                 product_id: product_id
//             },
           
//             success: function(response) {
//                 if (response) {
//                     var html = '<table class="size-variants-table">';
//                     html += '<tr><th>Size</th><th>Price</th><th>Quantity</th></tr>';
//                     $.each(response, function(index, sizeData) {
//                         var priceHtml = $('<div/>').html(sizeData.price).text();
//                         html += '<tr>';
//                         html += '<td>' + sizeData.size + '</td>';
//                         html += '<td>' + priceHtml + '</td>';
//                         html += '<td>' + sizeData.quantity + '</td>';
//                         html += '</tr>';
//                     });
//                     html += '</table>';
//                     $('#variant-data-placeholder').html(html);
//                 } else {
//                     console.log('No data received from server');
//                 }
//             }
           
//         });
        
//     });
// });



