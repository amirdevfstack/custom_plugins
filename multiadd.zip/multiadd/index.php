<?php
/*
Plugin Name: WooCommerce Color Variants
Description: Customizes WooCommerce product details page to display color variants and sizes in a table.
Version: 1.0
Author: Aamir Shahzad
*/

function woocommerce_color_variants_scripts() {
    wp_enqueue_style('custom-product-css', plugin_dir_url(__FILE__) . 'assets/css/style.css');
    wp_enqueue_script('woocommerce-color-variants-script', plugin_dir_url(__FILE__) . 'assets/js/woocommerce-color-variants.js', array('jquery'), '1.0', true);
    wp_localize_script('woocommerce-color-variants-script', 'woocommerce_color_variants_ajax', array('ajax_url' => admin_url('admin-ajax.php')));
}
add_action('wp_enqueue_scripts', 'woocommerce_color_variants_scripts');


add_action('wp_ajax_get_sizes_for_color_variant', 'get_sizes_for_color_variant_callback');
add_action('wp_ajax_nopriv_get_sizes_for_color_variant', 'get_sizes_for_color_variant_callback');

function get_sizes_for_color_variant_callback() {
    $data = [];
    $color_variant = isset($_POST['color_variant']) ? $_POST['color_variant'] : '';
    $product_id = isset($_POST['product_id']) ? $_POST['product_id'] : '';
    if ($color_variant && $product_id) {
        $product = wc_get_product($product_id);

        if ($product) {
            $variations = $product->get_available_variations();
            $sizes = array();

            foreach ($variations as $variation) {
                if ($variation['attributes']['attribute_pa_color'] === $color_variant) {
                    $variation_product = wc_get_product($variation['variation_id']);

                    if ($variation_product) {
                        $size = isset($variation['attributes']['attribute_pa_size']) ? $variation['attributes']['attribute_pa_size'] : '';
                        $price = $variation_product->get_price();
                        $quantity = $variation_product->get_stock_quantity();
                        $sizes[] = array(
                            'size' => $size,
                            'price' => $price,
                            'quantity' => $quantity,
                            'variation_id' => $variation['variation_id']
                        );
                    }
                    
                }
            }

            wp_send_json($sizes);
        }
    }
}


add_action('wp_ajax_add_all_to_cart', 'add_all_to_cart_callback');
add_action('wp_ajax_nopriv_add_all_to_cart', 'add_all_to_cart_callback');

function add_all_to_cart_callback() {
    $items = isset($_POST['items']) ? $_POST['items'] : [];
  
    foreach ($items as $item) {
        $product_id = $item['product_id'];
        $variation_id = $item['variation_id'];
        $quantity = $item['quantity'];
        $color_variant = $item['color_variant']; 
        if ($product_id && $variation_id && $quantity) {
            WC()->cart->add_to_cart($product_id, $quantity, $variation_id, array('color_variant' => $color_variant));
        }
    }

    wp_send_json_success();
}



add_filter( 'auto_update_plugin', 'disable_auto_update_for_variation_swatches', 10, 2 );

function disable_auto_update_for_variation_swatches( $update, $item ) {
   
    if ( $item->slug === 'woo-variation-swatches' ) {
        return false;
    }
    return $update;
}


add_action('woocommerce_before_add_to_cart_button', 'append_variant_data_before_add_to_cart');

function append_variant_data_before_add_to_cart() {
    global $product;

    if ($product->is_type('variable')) {
        echo '<div id="variant-data-placeholder">this is response div</div>';
    }
}
